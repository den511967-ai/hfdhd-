const featureStates = {};
const sliderStates = {};
let startTime = Date.now();
let currentUser = 'FTSyxcal';
let currentTheme = '#6366f1';
let panicKey = 'Insert';
let streamProof = false;
let currentLayout = 'default';

function saveConfig() {
    const config = {
        featureStates: featureStates,
        sliderStates: sliderStates,
        theme: currentTheme,
        panicKey: panicKey,
        streamProof: streamProof,
        layout: currentLayout,
        timestamp: Date.now()
    };
    
    const configName = prompt('Enter config name:', 'config_' + Date.now());
    if (configName) {
        const configs = JSON.parse(localStorage.getItem('silentExternal_configs') || '{}');
        configs[configName] = config;
        localStorage.setItem('silentExternal_configs', JSON.stringify(configs));
        showNotification(`Config "${configName}" saved!`, 'success');
    }
}

function loadConfig() {
    const configs = JSON.parse(localStorage.getItem('silentExternal_configs') || '{}');
    const configNames = Object.keys(configs);
    
    if (configNames.length === 0) {
        showNotification('No saved configs found', 'error');
        return;
    }
    
    const configName = prompt('Available configs:\n' + configNames.join('\n') + '\n\nEnter config name to load:');
    if (configName && configs[configName]) {
        const config = configs[configName];
        
        Object.assign(featureStates, config.featureStates);
        Object.assign(sliderStates, config.sliderStates);
        currentTheme = config.theme || '#6366f1';
        panicKey = config.panicKey || 'Insert';
        streamProof = config.streamProof || false;
        currentLayout = config.layout || 'default';
        
        document.documentElement.style.setProperty('--primary', currentTheme);
        applyLayout(currentLayout);
        
        showNotification(`Config "${configName}" loaded!`, 'success');
        
        const activePage = document.querySelector('.menu-item.active');
        if (activePage) {
            loadPage(activePage.getAttribute('data-page'));
        }
    } else if (configName) {
        showNotification('Config not found', 'error');
    }
}

function resetConfig() {
    if (confirm('Are you sure you want to reset all settings? This cannot be undone.')) {
        Object.keys(featureStates).forEach(key => {
            featureStates[key] = false;
        });
        Object.keys(sliderStates).forEach(key => {
            delete sliderStates[key];
        });
        
        currentTheme = '#6366f1';
        panicKey = 'Insert';
        streamProof = false;
        currentLayout = 'default';
        
        document.documentElement.style.setProperty('--primary', currentTheme);
        applyLayout('default');
        
        showNotification('All settings reset to default', 'success');
        
        const activePage = document.querySelector('.menu-item.active');
        if (activePage) {
            loadPage(activePage.getAttribute('data-page'));
        }
    }
}

function showNotification(message, type) {
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.textContent = message;
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.classList.add('show');
    }, 10);
    
    setTimeout(() => {
        notification.classList.remove('show');
        setTimeout(() => notification.remove(), 300);
    }, 3000);
}

document.addEventListener('keydown', function(e) {
    const keyMap = {
        'Insert': 'Insert',
        'Delete': 'Delete',
        'End': 'End',
        'Page Down': 'PageDown',
        'F12': 'F12'
    };
    
    if (e.key === keyMap[panicKey]) {
        e.preventDefault();
        panicMode();
    }
});

function panicMode() {
    Object.keys(featureStates).forEach(key => {
        featureStates[key] = false;
    });
    
    showNotification('PANIC MODE: All features disabled!', 'error');
    
    const activePage = document.querySelector('.menu-item.active');
    if (activePage) {
        loadPage(activePage.getAttribute('data-page'));
    }
}

function getUptime() {
    const elapsed = Date.now() - startTime;
    const hours = Math.floor(elapsed / 3600000);
    const minutes = Math.floor((elapsed % 3600000) / 60000);
    return `${hours}h ${minutes}m`;
}

function getActiveFeatures() {
    return Object.values(featureStates).filter(state => state === true).length;
}

function togglePassword() {
    const passwordInput = document.getElementById('password');
    const toggleIcon = document.querySelector('.password-toggle-icon');
    
    if (passwordInput.style.webkitTextSecurity === 'disc') {
        toggleIcon.style.animation = 'morphToHide 0.3s ease forwards';
        passwordInput.style.webkitTextSecurity = 'none';
        passwordInput.style.filter = 'blur(0px)';
        passwordInput.style.animation = 'revealText 0.4s ease';
    } else {
        toggleIcon.style.animation = 'morphToShow 0.3s ease forwards';
        passwordInput.style.webkitTextSecurity = 'disc';
        passwordInput.style.filter = 'blur(6px)';
        passwordInput.style.animation = 'hideText 0.4s ease';
    }
}

function handleLogin(event) {
    event.preventDefault();
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    const errorDiv = document.getElementById('login-error');
    
    if (username === 'FTSyxcal' && password === '1234') {
        currentUser = username;
        document.getElementById('login-screen').style.display = 'none';
        document.getElementById('loading-screen').style.display = 'flex';
        
        let progress = 0;
        const circle = document.getElementById('progress-circle');
        const percentage = document.querySelector('.loading-percentage');
        const loadingText = document.querySelector('.loading-text');
        const circumference = 339.292;
        
        const messages = [
            'Initializing...',
            'Loading modules...',
            'Connecting to server...',
            'Verifying credentials...',
            'Loading features...',
            'Almost ready...'
        ];
        
        const interval = setInterval(() => {
            progress += 2;
            
            const offset = circumference - (progress / 100) * circumference;
            circle.style.strokeDashoffset = offset;
            
            const red = Math.floor(239 - (progress / 100) * 223);
            const green = Math.floor(68 + (progress / 100) * 117);
            circle.style.stroke = `rgb(${red}, ${green}, 68)`;
            
            percentage.style.opacity = '0';
            setTimeout(() => {
                percentage.textContent = progress + '%';
                percentage.style.opacity = '1';
            }, 100);
            
            const messageIndex = Math.floor((progress / 100) * messages.length);
            if (loadingText.textContent !== messages[messageIndex]) {
                loadingText.style.opacity = '0';
                setTimeout(() => {
                    loadingText.textContent = messages[Math.min(messageIndex, messages.length - 1)];
                    loadingText.style.opacity = '1';
                }, 150);
            }
            
            if (progress >= 100) {
                clearInterval(interval);
                setTimeout(() => {
                    document.getElementById('loading-screen').style.display = 'none';
                    document.getElementById('main-app').style.display = 'flex';
                    initializeApp();
                }, 500);
            }
        }, 30);
    } else {
        errorDiv.textContent = 'Invalid username or password';
        setTimeout(() => errorDiv.textContent = '', 3000);
    }
    
    return false;
}

function initializeApp() {
    document.querySelectorAll('.menu-item').forEach(item => {
        item.onclick = function() {
            document.querySelectorAll('.menu-item').forEach(i => i.classList.remove('active'));
            this.classList.add('active');
            loadPage(this.getAttribute('data-page'));
        };
    });
    
    loadPage('dashboard');
}

const pages = {
    dashboard: {
        title: 'Dashboard',
        subtitle: 'Overview and system information',
        isDashboard: true
    },
    
    aimbot: {
        title: 'Aimbot',
        subtitle: 'Advanced targeting system with smooth aim and prediction',
        features: [
            { title: 'Enable Aimbot', description: 'Master toggle for all aimbot features', type: 'toggle', active: false },
            { title: 'Smooth Aim', description: 'Smoothly track targets for natural movement', type: 'slider', value: 75, min: 0, max: 100 },
            { title: 'FOV Circle', description: 'Field of view for target acquisition', type: 'slider', value: 90, min: 10, max: 360 },
            { title: 'Target Bone', description: 'Select which bone to target', type: 'dropdown', options: ['Head', 'Neck', 'Chest', 'Stomach', 'Pelvis'] },
            { title: 'Aim Key', description: 'Keybind to activate aimbot', type: 'dropdown', options: ['Mouse 4', 'Mouse 5', 'Shift', 'Alt', 'Ctrl'] },
            { title: 'Prediction', description: 'Predict enemy movement for better accuracy', type: 'toggle', active: false }
        ]
    },
    
    triggerbot: {
        title: 'Triggerbot',
        subtitle: 'Automatic shooting when crosshair is on target',
        features: [
            { title: 'Enable Triggerbot', description: 'Automatically shoot when aiming at enemies', type: 'toggle', active: false },
            { title: 'Reaction Time', description: 'Delay before shooting (ms)', type: 'slider', value: 50, min: 0, max: 500 },
            { title: 'Trigger Key', description: 'Hold key to enable triggerbot', type: 'dropdown', options: ['Always On', 'Mouse 4', 'Mouse 5', 'Shift', 'Alt'] },
            { title: 'Hitbox Filter', description: 'Only trigger on specific hitboxes', type: 'dropdown', options: ['All', 'Head Only', 'Upper Body', 'Lower Body'] },
            { title: 'Team Check', description: 'Prevent shooting teammates', type: 'toggle', active: false },
            { title: 'Burst Fire', description: 'Fire in controlled bursts', type: 'toggle', active: false }
        ]
    },
    
    recoil: {
        title: 'Recoil Control',
        subtitle: 'Eliminate weapon recoil and spread',
        features: [
            { title: 'No Recoil', description: 'Remove all weapon recoil', type: 'toggle', active: false },
            { title: 'Recoil Compensation', description: 'Amount of recoil to compensate', type: 'slider', value: 100, min: 0, max: 100 },
            { title: 'No Spread', description: 'Remove bullet spread', type: 'toggle', active: false },
            { title: 'Weapon Type', description: 'Select weapon for custom recoil patterns', type: 'dropdown', options: ['Auto Detect', 'Rifle', 'SMG', 'Pistol', 'Sniper'] },
            { title: 'Vertical Control', description: 'Vertical recoil compensation strength', type: 'slider', value: 85, min: 0, max: 100 },
            { title: 'Horizontal Control', description: 'Horizontal recoil compensation strength', type: 'slider', value: 75, min: 0, max: 100 }
        ]
    },
    
    esp: {
        title: 'ESP / Wallhack',
        subtitle: 'See enemies through walls and objects',
        features: [
            { title: 'Enable ESP', description: 'Master toggle for all ESP features', type: 'toggle', active: false },
            { title: 'Box ESP', description: 'Draw boxes around players', type: 'toggle', active: false },
            { title: 'Skeleton ESP', description: 'Show player skeleton', type: 'toggle', active: false },
            { title: 'Health Bar', description: 'Display player health', type: 'toggle', active: false },
            { title: 'Name ESP', description: 'Show player names', type: 'toggle', active: false },
            { title: 'Distance ESP', description: 'Show distance to players', type: 'toggle', active: false },
            { title: 'Weapon ESP', description: 'Display equipped weapons', type: 'toggle', active: false },
            { title: 'Max Distance', description: 'Maximum ESP render distance', type: 'slider', value: 500, min: 50, max: 1000 }
        ]
    },
    
    chams: {
        title: 'Chams',
        subtitle: 'Highlight players with colored overlays',
        features: [
            { title: 'Enable Chams', description: 'Highlight players through walls', type: 'toggle', active: false },
            { title: 'Visible Color', description: 'Color for visible players', type: 'colors', colors: ['#00ff00', '#00ffff', '#ff00ff', '#ffff00', '#ff0000', '#0000ff'] },
            { title: 'Hidden Color', description: 'Color for players behind walls', type: 'colors', colors: ['#ff0000', '#ff6600', '#ff00ff', '#0000ff', '#00ff00', '#ffff00'] },
            { title: 'Chams Style', description: 'Visual style for chams', type: 'dropdown', options: ['Flat', 'Wireframe', 'Glow', 'Metallic', 'Glass'] },
            { title: 'Opacity', description: 'Chams transparency', type: 'slider', value: 80, min: 0, max: 100 },
            { title: 'Team Chams', description: 'Apply chams to teammates', type: 'toggle', active: false }
        ]
    },
    
    glow: {
        title: 'Glow ESP',
        subtitle: 'Add glowing outlines to players',
        features: [
            { title: 'Enable Glow', description: 'Add glow effect to players', type: 'toggle', active: false },
            { title: 'Glow Intensity', description: 'Brightness of glow effect', type: 'slider', value: 70, min: 0, max: 100 },
            { title: 'Glow Color', description: 'Select glow color', type: 'colors', colors: ['#6366f1', '#8b5cf6', '#ec4899', '#f59e0b', '#10b981', '#06b6d4'] },
            { title: 'Glow Style', description: 'Glow rendering style', type: 'dropdown', options: ['Soft', 'Hard', 'Pulsing', 'Rainbow', 'Team Based'] },
            { title: 'Pulse Speed', description: 'Speed of pulsing effect', type: 'slider', value: 50, min: 0, max: 100 },
            { title: 'Through Walls', description: 'Show glow through walls', type: 'toggle', active: false }
        ]
    },
    
    bhop: {
        title: 'Bunny Hop',
        subtitle: 'Automatic jumping for increased speed',
        features: [
            { title: 'Enable Bhop', description: 'Automatically jump when landing', type: 'toggle', active: false },
            { title: 'Perfect Timing', description: 'Jump at perfect frame for max speed', type: 'toggle', active: false },
            { title: 'Jump Key', description: 'Key to hold for bunny hopping', type: 'dropdown', options: ['Space', 'Mouse Wheel', 'V', 'C', 'X'] },
            { title: 'Max Speed', description: 'Maximum bhop speed multiplier', type: 'slider', value: 150, min: 100, max: 300 },
            { title: 'Auto Strafe', description: 'Automatically strafe while jumping', type: 'toggle', active: false },
            { title: 'Legit Mode', description: 'Add randomization to avoid detection', type: 'toggle', active: false }
        ]
    },
    
    strafe: {
        title: 'Auto Strafe',
        subtitle: 'Automatic air strafing for movement',
        features: [
            { title: 'Enable Auto Strafe', description: 'Automatically strafe in air', type: 'toggle', active: false },
            { title: 'Strafe Smoothness', description: 'How smooth the strafing is', type: 'slider', value: 80, min: 0, max: 100 },
            { title: 'Turn Speed', description: 'Speed of directional changes', type: 'slider', value: 60, min: 0, max: 100 },
            { title: 'Strafe Type', description: 'Strafing algorithm', type: 'dropdown', options: ['Directional', 'Rage', 'Legit', 'Silent', 'Hybrid'] },
            { title: 'Retrack', description: 'Automatically retrack to target', type: 'toggle', active: false }
        ]
    },
    
    speed: {
        title: 'Speed Hack',
        subtitle: 'Increase movement speed',
        features: [
            { title: 'Enable Speed Hack', description: 'Increase player movement speed', type: 'toggle', active: false },
            { title: 'Speed Multiplier', description: 'Movement speed increase', type: 'slider', value: 150, min: 100, max: 500 },
            { title: 'Speed Key', description: 'Hold key to activate speed', type: 'dropdown', options: ['Always On', 'Shift', 'Ctrl', 'Alt', 'Mouse 4'] },
            { title: 'Fly Mode', description: 'Enable flying', type: 'toggle', active: false },
            { title: 'Fly Speed', description: 'Flying speed multiplier', type: 'slider', value: 200, min: 100, max: 1000 }
        ]
    },
    
    radar: {
        title: 'Radar Hack',
        subtitle: 'Show all players on radar',
        features: [
            { title: 'Enable Radar', description: 'Show all players on minimap', type: 'toggle', active: false },
            { title: 'Radar Size', description: 'Size of radar overlay', type: 'slider', value: 200, min: 100, max: 500 },
            { title: 'Radar Position', description: 'Screen position of radar', type: 'dropdown', options: ['Top Left', 'Top Right', 'Bottom Left', 'Bottom Right', 'Center'] },
            { title: 'Show Enemies', description: 'Display enemy positions', type: 'toggle', active: false },
            { title: 'Show Teammates', description: 'Display teammate positions', type: 'toggle', active: false },
            { title: 'Radar Zoom', description: 'Zoom level of radar', type: 'slider', value: 100, min: 50, max: 200 }
        ]
    },
    
    skinchanger: {
        title: 'Skin Changer',
        subtitle: 'Change weapon and player skins',
        features: [
            { title: 'Enable Skin Changer', description: 'Apply custom skins', type: 'toggle', active: false },
            { title: 'Weapon Skin', description: 'Select weapon skin', type: 'dropdown', options: ['Default', 'Dragon Lore', 'Howl', 'Fade', 'Asiimov', 'Hyper Beast'] },
            { title: 'Knife Model', description: 'Change knife model', type: 'dropdown', options: ['Default', 'Karambit', 'Butterfly', 'M9 Bayonet', 'Talon', 'Ursus'] },
            { title: 'Glove Skin', description: 'Select glove skin', type: 'dropdown', options: ['None', 'Crimson Kimono', 'Pandora Box', 'Emerald Web', 'Vice'] },
            { title: 'Wear Value', description: 'Skin wear condition', type: 'slider', value: 0, min: 0, max: 100 },
            { title: 'StatTrak', description: 'Enable StatTrak counter', type: 'toggle', active: false }
        ]
    },
    
    settings: {
        title: 'Settings',
        subtitle: 'Configure application preferences',
        features: [
            { title: 'Theme Color', description: 'Choose accent color', type: 'colors', colors: ['#6366f1', '#8b5cf6', '#ec4899', '#f59e0b', '#10b981', '#06b6d4'] },
            { title: 'Layout', description: 'Choose UI layout', type: 'dropdown', options: ['Default', 'Compact', 'Expanded', 'Custom'] },
            { title: 'Panic Key', description: 'Emergency disable all features', type: 'dropdown', options: ['Insert', 'Delete', 'End', 'Page Down', 'F12'] },
            { title: 'Config Actions', description: 'Save and load configurations', type: 'buttons', buttons: ['Save Config', 'Load Config', 'Reset All'] },
            { title: 'Stream Proof', description: 'Hide overlay from screen capture', type: 'toggle', active: false }
        ]
    }
};

function loadPage(pageName) {
    const content = document.getElementById('page-content');
    const page = pages[pageName];
    
    if (!page) {
        console.error('Page not found:', pageName);
        return;
    }
    
    if (page.isDashboard) {
        renderDashboard(content);
    } else {
        renderFeaturePage(page, content, pageName);
    }
}

function renderDashboard(content) {
    let html = `
        <div class="page-title">Dashboard</div>
        <div class="page-subtitle">Overview and system information</div>
        
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-label">STATUS</div>
                <div class="stat-value" style="color: #10b981">Active</div>
            </div>
            <div class="stat-card">
                <div class="stat-label">VERSION</div>
                <div class="stat-value" style="color: #6366f1">1.0</div>
            </div>
            <div class="stat-card">
                <div class="stat-label">UPTIME</div>
                <div class="stat-value" style="color: #8b5cf6">${getUptime()}</div>
            </div>
            <div class="stat-card">
                <div class="stat-label">CURRENT USER</div>
                <div class="stat-value" style="color: #ec4899">${currentUser}</div>
            </div>
        </div>
        
        <div class="info-grid">
            <div class="info-card">
                <div class="info-icon">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <polyline points="20 6 9 17 4 12"></polyline>
                    </svg>
                </div>
                <div class="info-content">
                    <div class="info-title">System Status</div>
                    <div class="info-text">All features operational and running smoothly</div>
                </div>
            </div>
            <div class="info-card">
                <div class="info-icon">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <polyline points="23 4 23 10 17 10"></polyline>
                        <path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"></path>
                    </svg>
                </div>
                <div class="info-content">
                    <div class="info-title">Last Update</div>
                    <div class="info-text">Updated today - Version 1.0</div>
                </div>
            </div>
            <div class="info-card">
                <div class="info-icon">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"></polygon>
                    </svg>
                </div>
                <div class="info-content">
                    <div class="info-title">Active Features</div>
                    <div class="info-text">${getActiveFeatures()} features currently enabled</div>
                </div>
            </div>
            <div class="info-card">
                <div class="info-icon">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <line x1="18" y1="20" x2="18" y2="10"></line>
                        <line x1="12" y1="20" x2="12" y2="4"></line>
                        <line x1="6" y1="20" x2="6" y2="14"></line>
                    </svg>
                </div>
                <div class="info-content">
                    <div class="info-title">Performance</div>
                    <div class="info-text">CPU: 12% | RAM: 245MB | FPS: 60</div>
                </div>
            </div>
        </div>
    `;
    
    content.innerHTML = html;
}

function renderFeaturePage(page, content, pageName) {
    let html = `
        <div class="page-title">${page.title}</div>
        <div class="page-subtitle">${page.subtitle}</div>
        <div class="feature-grid">
    `;
    
    page.features.forEach((feature, index) => {
        const featureId = `${pageName}_${index}`;
        if (featureStates[featureId] === undefined) {
            featureStates[featureId] = feature.active || false;
        }
        
        html += `<div class="feature-card">`;
        html += `<div class="feature-header">`;
        html += `<div class="feature-title">${feature.title}</div>`;
        
        if (feature.type === 'toggle') {
            html += `<div class="toggle-switch ${featureStates[featureId] ? 'active' : ''}" onclick="toggleSwitch(this, '${featureId}')"></div>`;
        }
        
        html += `</div>`;
        html += `<div class="feature-description">${feature.description}</div>`;
        
        if (feature.type === 'slider') {
            const sliderId = `${pageName}_slider_${index}`;
            const savedValue = sliderStates[sliderId] !== undefined ? sliderStates[sliderId] : feature.value;
            const percent = ((savedValue - (feature.min || 0)) / ((feature.max || 100) - (feature.min || 0))) * 100;
            html += `
                <div class="slider-container">
                    <div class="slider-header">
                        <span class="slider-label">${feature.title}</span>
                        <span class="slider-value">${savedValue}</span>
                    </div>
                    <div class="slider-track" data-slider-id="${sliderId}" onclick="updateSlider(this, event)">
                        <div class="slider-fill" style="width: ${percent}%">
                            <div class="slider-handle"></div>
                        </div>
                    </div>
                </div>
            `;
        }
        
        if (feature.type === 'colors') {
            html += `<div class="color-picker-grid">`;
            feature.colors.forEach(color => {
                const selected = color === currentTheme ? 'style="border: 2px solid white"' : '';
                html += `<div class="color-option" ${selected} style="background: ${color}" onclick="selectColor(this)"></div>`;
            });
            html += `</div>`;
        }
        
        if (feature.type === 'buttons') {
            html += `<div class="button-group">`;
            feature.buttons.forEach(btn => {
                let onclick = '';
                if (btn === 'Save Config') onclick = 'onclick="saveConfig()"';
                else if (btn === 'Load Config') onclick = 'onclick="loadConfig()"';
                else if (btn === 'Reset All') onclick = 'onclick="resetConfig()"';
                
                html += `<button class="btn" ${onclick}>${btn}</button>`;
            });
            html += `</div>`;
        }
        
        if (feature.type === 'dropdown' && feature.title === 'Panic Key') {
            html += createCustomDropdown('panic-key', feature.options, panicKey, (value) => {
                panicKey = value;
                showNotification('Panic key set to ' + value, 'success');
            });
        } else if (feature.type === 'dropdown' && feature.title === 'Layout') {
            html += createCustomDropdown('layout', feature.options, currentLayout.charAt(0).toUpperCase() + currentLayout.slice(1), (value) => {
                changeLayout(value);
            });
        } else if (feature.type === 'dropdown') {
            html += createCustomDropdown(`dropdown_${pageName}_${index}`, feature.options, feature.options[0], null);
        }
        
        html += `</div>`;
    });
    
    html += `</div>`;
    content.innerHTML = html;
}

function toggleSwitch(element, featureId) {
    element.classList.toggle('active');
    featureStates[featureId] = element.classList.contains('active');
    
    if (featureId.includes('settings') && element.parentElement.querySelector('.feature-title').textContent === 'Stream Proof') {
        streamProof = element.classList.contains('active');
        showNotification(streamProof ? 'Stream proof enabled' : 'Stream proof disabled', 'success');
    }
}

function updateSlider(track, event) {
    const rect = track.getBoundingClientRect();
    const percent = Math.max(0, Math.min(100, ((event.clientX - rect.left) / rect.width) * 100));
    const value = Math.round(percent);
    
    const fill = track.querySelector('.slider-fill');
    const valueLabel = track.parentElement.querySelector('.slider-value');
    
    fill.style.width = percent + '%';
    valueLabel.textContent = value;
    
    const sliderId = track.getAttribute('data-slider-id');
    if (sliderId) {
        sliderStates[sliderId] = value;
    }
}

document.addEventListener('mousedown', function(e) {
    if (e.target.closest('.slider-track')) {
        const track = e.target.closest('.slider-track');
        
        function onMouseMove(moveEvent) {
            updateSlider(track, moveEvent);
        }
        
        function onMouseUp() {
            document.removeEventListener('mousemove', onMouseMove);
            document.removeEventListener('mouseup', onMouseUp);
        }
        
        updateSlider(track, e);
        document.addEventListener('mousemove', onMouseMove);
        document.addEventListener('mouseup', onMouseUp);
    }
});

function selectColor(element) {
    document.querySelectorAll('.color-option').forEach(el => {
        el.style.borderColor = 'transparent';
    });
    element.style.borderColor = 'white';
    
    const color = element.style.background;
    currentTheme = color;
    document.documentElement.style.setProperty('--primary', color);
    showNotification('Theme color updated', 'success');
}

const dropdownCallbacks = {};

function createCustomDropdown(id, options, selected, callback) {
    if (callback) {
        dropdownCallbacks[id] = callback;
    }
    
    let html = `
        <div class="custom-dropdown" data-dropdown-id="${id}">
            <div class="dropdown-header" onclick="toggleDropdown('${id}')">
                <span class="dropdown-selected">${selected}</span>
                <span class="dropdown-arrow">▼</span>
            </div>
            <div class="dropdown-list">
    `;
    
    options.forEach(opt => {
        const selectedClass = opt === selected ? 'selected' : '';
        html += `<div class="dropdown-option ${selectedClass}" onclick="selectDropdownOption('${id}', '${opt}')">${opt}</div>`;
    });
    
    html += `
            </div>
        </div>
    `;
    
    return html;
}

function toggleDropdown(id) {
    const dropdown = document.querySelector(`[data-dropdown-id="${id}"]`);
    if (!dropdown) return;
    
    const header = dropdown.querySelector('.dropdown-header');
    const list = dropdown.querySelector('.dropdown-list');
    const card = dropdown.closest('.feature-card');
    
    document.querySelectorAll('.dropdown-header.active').forEach(h => {
        if (h !== header) {
            h.classList.remove('active');
            h.nextElementSibling.classList.remove('active');
            const otherCard = h.closest('.feature-card');
            if (otherCard) otherCard.style.zIndex = '1';
        }
    });
    
    const isOpening = !header.classList.contains('active');
    
    header.classList.toggle('active');
    list.classList.toggle('active');
    
    if (card) {
        card.style.zIndex = isOpening ? '100' : '1';
    }
}

function selectDropdownOption(id, value) {
    const dropdown = document.querySelector(`[data-dropdown-id="${id}"]`);
    if (!dropdown) return;
    
    const header = dropdown.querySelector('.dropdown-header');
    const list = dropdown.querySelector('.dropdown-list');
    const selected = dropdown.querySelector('.dropdown-selected');
    
    selected.textContent = value;
    
    dropdown.querySelectorAll('.dropdown-option').forEach(opt => {
        opt.classList.remove('selected');
        if (opt.textContent === value) {
            opt.classList.add('selected');
        }
    });
    
    header.classList.remove('active');
    list.classList.remove('active');
    
    if (dropdownCallbacks[id]) {
        dropdownCallbacks[id](value);
    }
}

document.addEventListener('click', function(e) {
    if (!e.target.closest('.custom-dropdown')) {
        document.querySelectorAll('.dropdown-header.active').forEach(header => {
            header.classList.remove('active');
            header.nextElementSibling.classList.remove('active');
            const card = header.closest('.feature-card');
            if (card) card.style.zIndex = '1';
        });
    }
});

function closeApp() {
    if (window.chrome && window.chrome.webview) {
        window.chrome.webview.postMessage('close');
    }
}

function minimizeApp() {
    if (window.chrome && window.chrome.webview) {
        window.chrome.webview.postMessage('minimize');
    }
}

function changeLayout(layout) {
    currentLayout = layout.toLowerCase();
    applyLayout(currentLayout);
    showNotification(`Layout changed to ${layout}`, 'success');
}

function applyLayout(layout) {
    const root = document.documentElement;
    
    switch(layout) {
        case 'compact':
            root.style.setProperty('--card-padding', '16px');
            root.style.setProperty('--card-gap', '12px');
            root.style.setProperty('--font-size-title', '14px');
            break;
        case 'expanded':
            root.style.setProperty('--card-padding', '32px');
            root.style.setProperty('--card-gap', '24px');
            root.style.setProperty('--font-size-title', '18px');
            break;
        case 'custom':
            const padding = prompt('Enter card padding (px):', '24');
            const gap = prompt('Enter card gap (px):', '20');
            const fontSize = prompt('Enter title font size (px):', '16');
            if (padding && gap && fontSize) {
                root.style.setProperty('--card-padding', padding + 'px');
                root.style.setProperty('--card-gap', gap + 'px');
                root.style.setProperty('--font-size-title', fontSize + 'px');
            }
            break;
        default:
            root.style.setProperty('--card-padding', '24px');
            root.style.setProperty('--card-gap', '20px');
            root.style.setProperty('--font-size-title', '16px');
    }
}

document.addEventListener('mousedown', function(e) {
    if (e.target.closest('button, input, select, .toggle-switch, .slider-track, .color-option, .menu-item')) {
        return;
    }
    
    const loginBox = e.target.closest('.login-box');
    const headerBar = e.target.closest('.header-bar');
    const sidebar = e.target.closest('.sidebar');
    
    if (loginBox || headerBar || sidebar) {
        if (window.chrome && window.chrome.webview) {
            window.chrome.webview.postMessage('drag');
        }
    }
});

document.addEventListener('DOMContentLoaded', function() {
    const inputs = document.querySelectorAll('input[type="text"]');
    
    inputs.forEach(input => {
        let smoothValue = '';
        let targetValue = '';
        let animationFrame = null;
        
        input.addEventListener('input', function() {
            targetValue = this.value;
            
            if (!animationFrame) {
                animateSmooth();
            }
        });
        
        function animateSmooth() {
            if (smoothValue !== targetValue) {
                if (smoothValue.length < targetValue.length) {
                    smoothValue = targetValue.substring(0, smoothValue.length + 1);
                } else if (smoothValue.length > targetValue.length) {
                    smoothValue = smoothValue.substring(0, smoothValue.length - 1);
                }
                
                const ghostText = document.createElement('div');
                ghostText.style.position = 'absolute';
                ghostText.style.left = '16px';
                ghostText.style.top = '12px';
                ghostText.style.color = 'rgba(99, 102, 241, 0.3)';
                ghostText.style.pointerEvents = 'none';
                ghostText.style.fontSize = '14px';
                ghostText.style.transition = 'all 0.15s ease';
                ghostText.textContent = smoothValue;
                
                const existing = input.parentElement.querySelector('.ghost-text');
                if (existing) existing.remove();
                
                ghostText.className = 'ghost-text';
                input.parentElement.style.position = 'relative';
                input.parentElement.appendChild(ghostText);
                
                animationFrame = requestAnimationFrame(animateSmooth);
            } else {
                const existing = input.parentElement.querySelector('.ghost-text');
                if (existing) existing.remove();
                animationFrame = null;
            }
        }
    });
});
